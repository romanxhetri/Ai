import React from 'react';
import Header from './components/Header';
import ThreeScene from './components/ThreeScene';
import ChatAssistant from './components/ChatAssistant';
import UpdateFeatures from './components/UpdateFeatures';

function App() {
  return (
    <div className="relative h-screen w-screen">
      {/* Header rendered at the top */}
      <Header />

      {/* Immersive background Three.js scene */}
      <ThreeScene />

      {/* Overlaid AI Assistant Chat Panel */}
      <ChatAssistant />

      {/* Update and development tools panel */}
      <UpdateFeatures />
    </div>
  );
}

export default App;