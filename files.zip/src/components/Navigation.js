import React, { useState } from 'react';
import { Draggable } from 'react-draggable'; // Install react-draggable package if needed

const navItems = [
  { name: 'Product', link: '#' },
  { name: 'Resources', link: '#' },
  { name: 'Pricing', link: '#' },
  { name: 'Blog', link: '#' },
  { name: 'Facebook', link: '#' },
  { name: 'ChatGPT', link: '#' },
  { name: 'Laptops', link: '#' },
  { name: 'AI Search', link: '#' },
  { name: 'Games', link: '#' },
  { name: 'Chat', link: '#' },
  { name: 'Media Creation', link: '#' }
];

function Navigation() {
  // Optionally, store positions for drag memory (this demo does not persist across reloads)
  const [positions, setPositions] = useState(
    navItems.map(() => ({ x: 0, y: 0 }))
  );

  const handleDragStop = (index, e, data) => {
    const newPositions = [...positions];
    newPositions[index] = { x: data.x, y: data.y };
    setPositions(newPositions);
  };

  return (
    <div className="flex space-x-4">
      {navItems.map((item, i) => (
        <Draggable
          key={i}
          defaultPosition={positions[i]}
          onStop={(e, data) => handleDragStop(i, e, data)}
        >
          <div className="p-2 rounded-lg bg-black bg-opacity-50 text-white hover:shadow-xl transition-all duration-300 cursor-pointer hover:scale-105">
            {item.name}
          </div>
        </Draggable>
      ))}
    </div>
  );
}

export default Navigation;