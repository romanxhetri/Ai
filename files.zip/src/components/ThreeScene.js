import React, { useRef, useEffect, useState } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import * as THREE from 'three';

const Effects = () => {
  const meshRef = useRef();
  const [effect, setEffect] = useState('thunder');
  const effects = ['thunder', 'fire', 'rain'];

  useEffect(() => {
    const interval = setInterval(() => {
      // Cycle effects every 5 seconds
      setEffect(prev => effects[(effects.indexOf(prev) + 1) % effects.length]);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // This is a simple placeholder for the different effects.
  // In a real application you would create particle systems, light flashes, custom shaders etc.
  useFrame(() => {
    if (meshRef.current) {
      meshRef.current.rotation.z += 0.005;
    }
  });

  let effectColor;
  switch (effect) {
    case 'thunder':
      effectColor = 'white';
      break;
    case 'fire':
      effectColor = 'orange';
      break;
    case 'rain':
      effectColor = 'blue';
      break;
    default:
      effectColor = 'gray';
  }

  return (
    <mesh ref={meshRef}>
      <boxGeometry args={[10, 10, 10]} />
      <meshStandardMaterial emissive={new THREE.Color(effectColor)} />
    </mesh>
  );
};

const ImmersiveBackground = () => {
  const { camera } = useThree();
  useEffect(() => {
    camera.position.z = 20;
  }, [camera]);
  return null;
};

function ThreeScene() {
  return (
    <Canvas className="absolute inset-0">
      <ambientLight intensity={0.5} />
      <pointLight position={[10, 10, 10]} />
      <ImmersiveBackground />
      <Effects />
    </Canvas>
  );
}

export default ThreeScene;