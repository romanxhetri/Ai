import React from 'react';
import Navigation from './Navigation';

function Header() {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 flex items-center px-4 py-2 bg-glass-dark backdrop-blur-xl shadow-md">
      {/* Animated 3D logo placeholder */}
      <div className="flex-1">
        <div className="w-16 h-16 animate-spin-slow">
          {/* You can replace this with your custom 3D logo using Three.js or a Lottie animation */}
          <img src="/logo.png" alt="SageX Logo" className="w-full h-full" />
        </div>
      </div>

      {/* Floating Navigation Buttons */}
      <div className="flex-1 flex justify-center">
        <Navigation />
      </div>

      {/* Glowing CTA button */}
      <div className="flex-1 flex justify-end">
        <button className="px-4 py-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg hover:shadow-2xl transition-all duration-300">
          Get Started
        </button>
      </div>
    </header>
  );
}

export default Header;