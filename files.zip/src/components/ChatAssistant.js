import React from 'react';

function ChatAssistant() {
  return (
    <div className="absolute bottom-5 right-5 w-96 h-128 bg-white bg-opacity-80 rounded-xl shadow-xl p-4 overflow-hidden">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-lg font-bold">SageX AI Assistant 🤖</h2>
        {/* Live chat opens a new page */}
        <button
          onClick={() => window.open('/live-chat', '_blank')}
          className="text-sm text-blue-500 underline"
        >
          Live Chat
        </button>
      </div>
      <div className="h-full overflow-y-auto">
        {/* Chat messages area (text chat, emojis, stickers, image support) */}
        <p className="mb-2">Hello! I am your friendly and witty assistant ready for deep, flash, and experimental thinking 😄🔥.</p>
        {/* More chat message components to be added */}
      </div>
      <div className="mt-2">
        {/* Input box for text messages */}
        <input
          type="text"
          placeholder="Type your message..."
          className="w-full border border-gray-300 rounded-lg p-2"
        />
      </div>
      <div className="mt-2 flex justify-between space-x-2">
        {/* Additional controls for voice, video calls etc. */}
        <button className="flex-1 bg-blue-600 text-white rounded-lg p-1">Voice Call 🎤</button>
        <button className="flex-1 bg-green-600 text-white rounded-lg p-1">Video Call 🎥</button>
      </div>
      <div className="mt-2">
        <button className="w-full bg-purple-500 text-white rounded-lg p-1">
          Screen Share & File Share 📁
        </button>
      </div>
    </div>
  );
}

export default ChatAssistant;